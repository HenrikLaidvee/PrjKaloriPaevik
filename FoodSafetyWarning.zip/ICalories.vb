﻿Public Interface ICalories
    Sub AddCalories(ByRef foodID As Integer, ByRef amount As Integer)
End Interface
