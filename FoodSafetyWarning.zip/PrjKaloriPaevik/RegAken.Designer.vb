﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RegAken
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtSugarLimit = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblEmailMaxWords = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cbAlcohol = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.chbUnhealthy = New System.Windows.Forms.CheckBox()
        Me.chbKosher = New System.Windows.Forms.CheckBox()
        Me.txtDailyCalories = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtGoalWeight = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.txtHeight = New System.Windows.Forms.TextBox()
        Me.lblHeight = New System.Windows.Forms.Label()
        Me.lblLastNameMaxWords = New System.Windows.Forms.Label()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.cmbYear = New System.Windows.Forms.ComboBox()
        Me.cmbMonth = New System.Windows.Forms.ComboBox()
        Me.cmbDay = New System.Windows.Forms.ComboBox()
        Me.lblWeight = New System.Windows.Forms.Label()
        Me.lblAge = New System.Windows.Forms.Label()
        Me.txtWeight = New System.Windows.Forms.TextBox()
        Me.lblLimitReached = New System.Windows.Forms.Label()
        Me.btnSeePassword = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.lblUsernameMaxWords = New System.Windows.Forms.Label()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.btnCreateAccount = New System.Windows.Forms.Button()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtSugarLimit)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.lblEmailMaxWords)
        Me.GroupBox1.Controls.Add(Me.txtEmail)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.cbAlcohol)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.chbUnhealthy)
        Me.GroupBox1.Controls.Add(Me.chbKosher)
        Me.GroupBox1.Controls.Add(Me.txtDailyCalories)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtGoalWeight)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.btnBack)
        Me.GroupBox1.Controls.Add(Me.txtHeight)
        Me.GroupBox1.Controls.Add(Me.lblHeight)
        Me.GroupBox1.Controls.Add(Me.lblLastNameMaxWords)
        Me.GroupBox1.Controls.Add(Me.lblLastName)
        Me.GroupBox1.Controls.Add(Me.txtLastName)
        Me.GroupBox1.Controls.Add(Me.cmbYear)
        Me.GroupBox1.Controls.Add(Me.cmbMonth)
        Me.GroupBox1.Controls.Add(Me.cmbDay)
        Me.GroupBox1.Controls.Add(Me.lblWeight)
        Me.GroupBox1.Controls.Add(Me.lblAge)
        Me.GroupBox1.Controls.Add(Me.txtWeight)
        Me.GroupBox1.Controls.Add(Me.lblLimitReached)
        Me.GroupBox1.Controls.Add(Me.btnSeePassword)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtPassword)
        Me.GroupBox1.Controls.Add(Me.lblPassword)
        Me.GroupBox1.Controls.Add(Me.lblUsernameMaxWords)
        Me.GroupBox1.Controls.Add(Me.lblFirstName)
        Me.GroupBox1.Controls.Add(Me.btnCreateAccount)
        Me.GroupBox1.Controls.Add(Me.txtUsername)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.GroupBox1.Location = New System.Drawing.Point(18, 18)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox1.Size = New System.Drawing.Size(1084, 804)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Kasutaja andmed"
        '
        'txtSugarLimit
        '
        Me.txtSugarLimit.Location = New System.Drawing.Point(287, 627)
        Me.txtSugarLimit.Name = "txtSugarLimit"
        Me.txtSugarLimit.Size = New System.Drawing.Size(149, 30)
        Me.txtSugarLimit.TabIndex = 38
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(53, 630)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(148, 25)
        Me.Label6.TabIndex = 37
        Me.Label6.Text = "Suhkru limiit(g):"
        '
        'lblEmailMaxWords
        '
        Me.lblEmailMaxWords.AutoSize = True
        Me.lblEmailMaxWords.Location = New System.Drawing.Point(776, 77)
        Me.lblEmailMaxWords.Name = "lblEmailMaxWords"
        Me.lblEmailMaxWords.Size = New System.Drawing.Size(34, 25)
        Me.lblEmailMaxWords.TabIndex = 36
        Me.lblEmailMaxWords.Text = "50"
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(287, 72)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(477, 30)
        Me.txtEmail.TabIndex = 35
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(165, 77)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(66, 25)
        Me.Label5.TabIndex = 34
        Me.Label5.Text = "Email:"
        '
        'cbAlcohol
        '
        Me.cbAlcohol.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbAlcohol.FormattingEnabled = True
        Me.cbAlcohol.Location = New System.Drawing.Point(287, 568)
        Me.cbAlcohol.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cbAlcohol.Name = "cbAlcohol"
        Me.cbAlcohol.Size = New System.Drawing.Size(151, 33)
        Me.cbAlcohol.TabIndex = 33
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(46, 573)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(155, 25)
        Me.Label4.TabIndex = 32
        Me.Label4.Text = "Akoholi limiit (g):"
        '
        'chbUnhealthy
        '
        Me.chbUnhealthy.AutoSize = True
        Me.chbUnhealthy.Location = New System.Drawing.Point(485, 408)
        Me.chbUnhealthy.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.chbUnhealthy.Name = "chbUnhealthy"
        Me.chbUnhealthy.Size = New System.Drawing.Size(247, 29)
        Me.chbUnhealthy.TabIndex = 30
        Me.chbUnhealthy.Text = "Ebatervisliku toidu teated"
        Me.chbUnhealthy.UseVisualStyleBackColor = True
        '
        'chbKosher
        '
        Me.chbKosher.AutoSize = True
        Me.chbKosher.Location = New System.Drawing.Point(485, 353)
        Me.chbKosher.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.chbKosher.Name = "chbKosher"
        Me.chbKosher.Size = New System.Drawing.Size(124, 29)
        Me.chbKosher.TabIndex = 29
        Me.chbKosher.Text = "Kosher toit"
        Me.chbKosher.UseVisualStyleBackColor = True
        '
        'txtDailyCalories
        '
        Me.txtDailyCalories.Location = New System.Drawing.Point(287, 515)
        Me.txtDailyCalories.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtDailyCalories.Name = "txtDailyCalories"
        Me.txtDailyCalories.Size = New System.Drawing.Size(151, 30)
        Me.txtDailyCalories.TabIndex = 27
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(16, 515)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(175, 25)
        Me.Label3.TabIndex = 26
        Me.Label3.Text = "Päevane kaloraaž:"
        '
        'txtGoalWeight
        '
        Me.txtGoalWeight.Location = New System.Drawing.Point(287, 459)
        Me.txtGoalWeight.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtGoalWeight.Name = "txtGoalWeight"
        Me.txtGoalWeight.Size = New System.Drawing.Size(151, 30)
        Me.txtGoalWeight.TabIndex = 25
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(74, 459)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(136, 25)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "Soovitud kaal:"
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.btnBack.Location = New System.Drawing.Point(287, 741)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(486, 51)
        Me.btnBack.TabIndex = 23
        Me.btnBack.Text = "Tagasi"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'txtHeight
        '
        Me.txtHeight.Location = New System.Drawing.Point(287, 404)
        Me.txtHeight.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtHeight.Name = "txtHeight"
        Me.txtHeight.Size = New System.Drawing.Size(151, 30)
        Me.txtHeight.TabIndex = 22
        '
        'lblHeight
        '
        Me.lblHeight.AutoSize = True
        Me.lblHeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.lblHeight.Location = New System.Drawing.Point(96, 408)
        Me.lblHeight.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblHeight.Name = "lblHeight"
        Me.lblHeight.Size = New System.Drawing.Size(121, 25)
        Me.lblHeight.TabIndex = 21
        Me.lblHeight.Text = "Pikkus (cm):"
        '
        'lblLastNameMaxWords
        '
        Me.lblLastNameMaxWords.AutoSize = True
        Me.lblLastNameMaxWords.Location = New System.Drawing.Point(776, 181)
        Me.lblLastNameMaxWords.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblLastNameMaxWords.Name = "lblLastNameMaxWords"
        Me.lblLastNameMaxWords.Size = New System.Drawing.Size(34, 25)
        Me.lblLastNameMaxWords.TabIndex = 20
        Me.lblLastNameMaxWords.Text = "30"
        '
        'lblLastName
        '
        Me.lblLastName.AutoSize = True
        Me.lblLastName.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.lblLastName.Location = New System.Drawing.Point(137, 176)
        Me.lblLastName.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(94, 25)
        Me.lblLastName.TabIndex = 19
        Me.lblLastName.Text = "Perenimi:"
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(287, 176)
        Me.txtLastName.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(478, 30)
        Me.txtLastName.TabIndex = 18
        '
        'cmbYear
        '
        Me.cmbYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbYear.FormattingEnabled = True
        Me.cmbYear.Location = New System.Drawing.Point(614, 284)
        Me.cmbYear.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbYear.Name = "cmbYear"
        Me.cmbYear.Size = New System.Drawing.Size(151, 33)
        Me.cmbYear.TabIndex = 16
        '
        'cmbMonth
        '
        Me.cmbMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbMonth.FormattingEnabled = True
        Me.cmbMonth.Location = New System.Drawing.Point(452, 284)
        Me.cmbMonth.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbMonth.Name = "cmbMonth"
        Me.cmbMonth.Size = New System.Drawing.Size(151, 33)
        Me.cmbMonth.TabIndex = 15
        '
        'cmbDay
        '
        Me.cmbDay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbDay.FormattingEnabled = True
        Me.cmbDay.Location = New System.Drawing.Point(287, 284)
        Me.cmbDay.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbDay.Name = "cmbDay"
        Me.cmbDay.Size = New System.Drawing.Size(151, 33)
        Me.cmbDay.TabIndex = 14
        '
        'lblWeight
        '
        Me.lblWeight.AutoSize = True
        Me.lblWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.lblWeight.Location = New System.Drawing.Point(131, 353)
        Me.lblWeight.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblWeight.Name = "lblWeight"
        Me.lblWeight.Size = New System.Drawing.Size(98, 25)
        Me.lblWeight.TabIndex = 13
        Me.lblWeight.Text = "Kaal (kg):"
        '
        'lblAge
        '
        Me.lblAge.AutoSize = True
        Me.lblAge.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.lblAge.Location = New System.Drawing.Point(62, 284)
        Me.lblAge.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblAge.Name = "lblAge"
        Me.lblAge.Size = New System.Drawing.Size(144, 25)
        Me.lblAge.TabIndex = 12
        Me.lblAge.Text = "Sünnikuupäev:"
        '
        'txtWeight
        '
        Me.txtWeight.Location = New System.Drawing.Point(287, 348)
        Me.txtWeight.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtWeight.Name = "txtWeight"
        Me.txtWeight.Size = New System.Drawing.Size(151, 30)
        Me.txtWeight.TabIndex = 11
        '
        'lblLimitReached
        '
        Me.lblLimitReached.AutoSize = True
        Me.lblLimitReached.Location = New System.Drawing.Point(412, 28)
        Me.lblLimitReached.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblLimitReached.Name = "lblLimitReached"
        Me.lblLimitReached.Size = New System.Drawing.Size(241, 25)
        Me.lblLimitReached.TabIndex = 9
        Me.lblLimitReached.Text = "Kasutajanime limiit on täis!"
        '
        'btnSeePassword
        '
        Me.btnSeePassword.Location = New System.Drawing.Point(784, 228)
        Me.btnSeePassword.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnSeePassword.Name = "btnSeePassword"
        Me.btnSeePassword.Size = New System.Drawing.Size(206, 46)
        Me.btnSeePassword.TabIndex = 8
        Me.btnSeePassword.Text = "Vaata parooli"
        Me.btnSeePassword.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(671, 239)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(0, 25)
        Me.Label1.TabIndex = 7
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(287, 228)
        Me.txtPassword.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword.Size = New System.Drawing.Size(478, 30)
        Me.txtPassword.TabIndex = 6
        '
        'lblPassword
        '
        Me.lblPassword.AutoSize = True
        Me.lblPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.lblPassword.Location = New System.Drawing.Point(167, 228)
        Me.lblPassword.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.Size = New System.Drawing.Size(74, 25)
        Me.lblPassword.TabIndex = 4
        Me.lblPassword.Text = "Parool:"
        '
        'lblUsernameMaxWords
        '
        Me.lblUsernameMaxWords.AutoSize = True
        Me.lblUsernameMaxWords.Location = New System.Drawing.Point(776, 128)
        Me.lblUsernameMaxWords.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblUsernameMaxWords.Name = "lblUsernameMaxWords"
        Me.lblUsernameMaxWords.Size = New System.Drawing.Size(34, 25)
        Me.lblUsernameMaxWords.TabIndex = 3
        Me.lblUsernameMaxWords.Text = "30"
        '
        'lblFirstName
        '
        Me.lblFirstName.AutoSize = True
        Me.lblFirstName.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.lblFirstName.Location = New System.Drawing.Point(148, 125)
        Me.lblFirstName.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(87, 25)
        Me.lblFirstName.TabIndex = 2
        Me.lblFirstName.Text = "Eesnimi:"
        '
        'btnCreateAccount
        '
        Me.btnCreateAccount.Location = New System.Drawing.Point(287, 679)
        Me.btnCreateAccount.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnCreateAccount.Name = "btnCreateAccount"
        Me.btnCreateAccount.Size = New System.Drawing.Size(486, 52)
        Me.btnCreateAccount.TabIndex = 0
        Me.btnCreateAccount.Text = "Loo kasutaja"
        Me.btnCreateAccount.UseVisualStyleBackColor = True
        '
        'txtUsername
        '
        Me.txtUsername.Location = New System.Drawing.Point(287, 121)
        Me.txtUsername.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(478, 30)
        Me.txtUsername.TabIndex = 1
        '
        'RegAken
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1120, 836)
        Me.Controls.Add(Me.GroupBox1)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "RegAken"
        Me.Text = "RegAken"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lblFirstName As Label
    Friend WithEvents btnCreateAccount As Button
    Friend WithEvents txtUsername As TextBox
    Friend WithEvents lblUsernameMaxWords As Label
    Friend WithEvents lblPassword As Label
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents btnSeePassword As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents lblLimitReached As Label
    Friend WithEvents lblWeight As Label
    Friend WithEvents lblAge As Label
    Friend WithEvents txtWeight As TextBox
    Friend WithEvents cmbYear As ComboBox
    Friend WithEvents cmbMonth As ComboBox
    Friend WithEvents cmbDay As ComboBox
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents lblLastNameMaxWords As Label
    Friend WithEvents lblLastName As Label
    Friend WithEvents txtHeight As TextBox
    Friend WithEvents lblHeight As Label
    Friend WithEvents btnBack As Button
    Friend WithEvents txtGoalWeight As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtDailyCalories As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents chbKosher As CheckBox
    Friend WithEvents chbUnhealthy As CheckBox
    Friend WithEvents Label4 As Label
    Friend WithEvents cbAlcohol As ComboBox
    Friend WithEvents lblEmailMaxWords As Label
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtSugarLimit As TextBox
End Class
