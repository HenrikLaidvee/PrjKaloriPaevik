﻿Public Interface ISuhkur
    Sub AddCalories(ByRef foodID As Integer)
    Sub SetCalorieLimit(ByRef limit As Integer)
End Interface
